#! /bin/sh

WwiseRootSrc=${1?:"Usage: $0 WwiseRootSrc WwiseRootDest"}
WwiseRootDest=${2?:"Usage: $0 WwiseRootSrc WwiseRootDest"}

declare -a Arches=("android-9_armeabi-v7a")
declare -a Includes=("SoundEngine/Platforms" "Tools")
declare -a Samples=("IntegrationDemo" "SoundEngine")

echo "Copy Android SDK binaries ..."
for a in "${Arches[@]}"; do
	cp -R "${WwiseRootSrc}/SDK/${a}" "${WwiseRootDest}/SDK"/
done

echo "Copy headers ..."
for i in "${Includes[@]}"; do
	mkdir -p "${WwiseRootDest}/SDK/include/AK/${i}" &> /dev/null
	cp -R "${WwiseRootSrc}/SDK/include/AK/${i}/Android" "${WwiseRootDest}/SDK/include/AK/${i}"/
done

echo "Copy sample code ..."
for s in "${Samples[@]}"; do
	cp -R "${WwiseRootSrc}/SDK/samples/${s}/Android" "${WwiseRootDest}/SDK/samples/${s}"/
done

echo "Done."
